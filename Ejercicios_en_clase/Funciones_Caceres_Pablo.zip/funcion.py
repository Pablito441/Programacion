def most(a,b):
    if a>b:
        return a
    else:
        return b

def least(a,b):
    if a<b:
        return a
    else:
        return b

#No estabamos utilizando los parametros de las funciones (a y b). Estabamos utilizando las variables globales x e y. 